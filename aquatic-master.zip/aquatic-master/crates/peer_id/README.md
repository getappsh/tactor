# aquatic_peer_id

Extract BitTorrent client information from announce request peer IDs.