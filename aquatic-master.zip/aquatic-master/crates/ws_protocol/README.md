# aquatic_ws_protocol: WebTorrent tracker protocol

[WebTorrent](https://github.com/webtorrent) tracker message parsing and
serialization.