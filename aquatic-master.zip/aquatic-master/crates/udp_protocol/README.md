# aquatic_udp_protocol: UDP BitTorrent tracker protocol

UDP BitTorrent tracker message parsing and serialization.

Implements [BEP 015](https://www.bittorrent.org/beps/bep_0015.html) ([more details](https://libtorrent.org/udp_tracker_protocol.html)).
